<?php

echo 'admin';