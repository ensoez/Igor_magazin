<?php
include 'template/header.php';
include 'template/login_form.php';
include 'template/footer.php';